package com.example.iran_safar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
